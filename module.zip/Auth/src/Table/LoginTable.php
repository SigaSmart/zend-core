<?php
/**
 * Created By: Claudio  Campos
 * E-Mail: callcocam@gmail.com
 */

namespace Auth\Table;


use Core\Table\AbstractTable;

class LoginTable extends AbstractTable
{

	protected $table = "users";
}