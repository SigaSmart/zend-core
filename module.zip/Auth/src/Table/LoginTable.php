<?php
/**
 * Created by PhpStorm.
 * User: caltj
 * Date: 18/12/2017
 * Time: 19:30
 */

namespace Auth\Table;


use Core\Table\AbstractTable;

class LoginTable extends AbstractTable
{

	protected $table = "users";
}