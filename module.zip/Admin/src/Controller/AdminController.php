<?php
/**
 * Created By: Claudio  Campos
 * E-Mail: callcocam@gmail.com
 */

namespace Admin\Controller;

use Core\Controller\AbstractController;
use Interop\Container\ContainerInterface;

class AdminController extends AbstractController
{

	public function __construct(ContainerInterface $container)
	{
		$this->container = $container;
	}

	public function moduleAction()
	{

		if($this->params()->fromPost()):
			$modules = path_modules('./data/Demo/*');
			$Md = $this->params()->fromPost();
			copiar_diretorio("./data/Demo","./module/{$Md['module']}",$Md['classes']);
			foreach ($modules as $module) {
				echo $module;
			}
			die;
		endif;
	}

}
