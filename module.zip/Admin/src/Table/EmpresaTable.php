<?php
/**
 * Created By: Claudio  Campos
 * E-Mail: callcocam@gmail.com
 */

namespace Admin\Table;


use Core\Model\AbstractModel;
use Core\Table\AbstractTable;

class EmpresaTable extends AbstractTable
{

	protected $table = "empresa";

	public function insert(AbstractModel $mode)
	{
		$mode->offsetSet('social', "Nova Empresa");
		$mode->offsetSet('created_at', date("Y-m-d H:i:s"));
		$mode->offsetSet('updated_at', date("Y-m-d H:i:s"));
		return parent::insert($mode);
	}
}