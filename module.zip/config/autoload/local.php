<?php
/**
 * Created by PhpStorm.
 * User: caltj
 * Date: 15/12/2017
 * Time: 12:54
 */
return [
	'db'=>[
		'dsn' => 'mysql:dbname=base;host=localhost',
		'username' => 'root',
		'password' => ''
	]
];